export const serviceUrl = "https://api.quicktagg.com/api/";

export const authUrl = "https://api.quicktagg.com/auth/";

export const logoUrl = "https://api.quicktagg.com/BranchLogo/";

